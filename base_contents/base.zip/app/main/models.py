MESSAGE= {
    'default': 'Hello! Flask app is running.'
}