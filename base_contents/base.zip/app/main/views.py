# Basic Views
from flask import Blueprint
from flask import render_template, request
from app.main.models import MESSAGE

default = Blueprint('default', __name__)

@default.route('/')
def home():
    return render_template('index.html', data=MESSAGE)