from flask import Flask
from app.main.views import default
from flask.ext.sqlalchemy import SQLAlchemy
from utils import get_instance_folder_path
import config

# create the app
# set the static folder and instance folder
app = Flask(__name__, 
    instance_path=get_instance_folder_path(),
    instance_relative_config=True)

# Set configuration
app.config.from_object('config.default')

app.config.from_pyfile('config.cfg')

app.config.from_envvar('APP_CONFIG_FILE')

# create db
db = SQLAlchemy(app)
db.create_all()

# register the blueprint
app.register_blueprint(default)