import os
os.environ['APP_CONFIG_FILE'] = '../config/development.py'

from app import app

app.run()